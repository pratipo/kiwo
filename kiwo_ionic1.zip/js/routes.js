angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('reference', {
    url: '/reference',
    templateUrl: 'templates/reference.html',
    controller: 'referenceCtrl'
  })

  .state('menu.patternCategories', {
    url: '/pattern-cats',
    views: {
      'side-menu21': {
        templateUrl: 'templates/patternCategories.html',
        controller: 'patternCategoriesCtrl'
      }
    }
  })

  .state('menu.patternDesigns', {
    url: '/pattern-designs',
    views: {
      'side-menu21': {
        templateUrl: 'templates/patternDesigns.html',
        controller: 'patternDesignsCtrl'
      }
    }
  })

  .state('menu.pattern', {
    url: '/pattern-item',
    views: {
      'side-menu21': {
        templateUrl: 'templates/pattern.html',
        controller: 'patternCtrl'
      }
    }
  })

  .state('editor', {
    url: '/editor',
    templateUrl: 'templates/editor.html',
    controller: 'editorCtrl'
  })

  .state('menu.settings', {
    url: '/settings',
    views: {
      'side-menu21': {
        templateUrl: 'templates/settings.html',
        controller: 'settingsCtrl'
      }
    }
  })

  .state('menu.login', {
    url: '/login',
    views: {
      'side-menu21': {
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    abstract:true
  })

$urlRouterProvider.otherwise('/side-menu21/pattern-cats')

  

});